"""Single source of truth for the package version (read by hatchling)."""

from __future__ import annotations

__version__ = "0.1.0"
